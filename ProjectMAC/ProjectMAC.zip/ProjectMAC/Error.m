function [errVelL2, errVelH1, errVelInfi, errPreL2] = Error(uh, vh, ph, uI, vI, pI)

n = size(uh,1);
uh = uh(:); vh = vh(:); ph = ph(:);
ue = uI - uh; ve = vI - vh; pe = pI - ph;

%% L2
erruL2 = norm(ue) / norm(uI);  errvL2 = norm(ve) / norm(vI);
errVelL2 = sqrt(erruL2^2 + errvL2^2);

%% H1
nx = n+1;  ny = n;  ex = ones(nx,1);  ey = ones(ny,1);
Tx = spdiags([-ex 2*ex -ex], -1:1, nx, nx);
Ty = spdiags([-ey 2*ey -ey], -1:1, ny, ny);
A = kron(speye(nx),Ty) + kron(Tx,speye(ny));
LEF = 1:ny;   RIG = ny*(nx-1)+1:ny*nx;
TOP = ny+1:ny:ny*(nx-2)+1; BOT = ny*2:ny:ny*(nx-1);
a = false;  a(LEF) = true;  a(RIG) = true; inteNodes = find(~a);
b = zeros(nx*ny,1);  b(TOP) = 1;  b(BOT) = 1;  Ae = spdiags(b, 0, nx*ny, nx*ny);
A = A + Ae;  ue = uI - uh;  ue = ue(inteNodes);
erruH1 = sqrt(ue'*A(inteNodes, inteNodes)*ue);
clear nx ny ex ey Tx Ty A a b Ae LEF RIG TOP BOT

nx = n;  ny = n+1;  ex = ones(nx,1);  ey = ones(ny,1);
Tx = spdiags([-ex 2*ex -ex], -1:1, nx, nx);
Ty = spdiags([-ey 2*ey -ey], -1:1, ny, ny);
A = kron(speye(nx),Ty) + kron(Tx,speye(ny));
TOP = 1:ny:ny*(nx-1)+1;  BOT = ny:ny:ny*nx;
LEF = 2:ny-1;  RIG = ny*(nx-1)+2:ny*nx-1;
a = false;  a(TOP) = true;  a(BOT) = true;  inteNodes = find(~a);
b = zeros(nx*ny,1);  b(LEF) = 1;  b(RIG) = 1;  Ae = spdiags(b, 0, nx*ny, nx*ny);
A = A + Ae;  ve = vI - vh;  ve = ve(inteNodes);
errvH1 = sqrt(ve'*A(inteNodes,inteNodes)*ve);
clear nx ny ex ey Tx Ty A a b Ae LEF RIG TOP BOT
errVelH1 = sqrt(erruH1^2 + errvH1^2);

%% Infinity
errVelInfi = max(sqrt(ue.^2 + ve.^2));


%% L2
errPreL2 = norm(pe) / norm(pI);

end